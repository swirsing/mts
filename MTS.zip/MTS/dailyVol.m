function [r,s] = dailyVol(rho,n_days,r_wd_lambda,r_wd_beta,s_wd_lambda,s_wd_beta,dtype)
%DAILYVOL Summary of this function goes here
%   Detailed explanation goes here
    Z = mvnrnd([0 0],[1 rho; rho 1],n_days);
    U = normcdf(Z);
    switch dtype %% TRMOD
        case 'weibull'
            r = wblinv(U(:,1),1./r_wd_lambda,r_wd_beta);
            s = wblinv(U(:,2),1./s_wd_lambda,s_wd_beta); 
    end


end

