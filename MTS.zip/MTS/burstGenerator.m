function [R,S] = burstGenerator(mu,rho,dst,v_min,v_max,v_av)
%BURSTGENERATOR Summary of this function goes here
%   Detailed explanation goes here

n_int = size(mu,1);
n_users = size(mu,2)/2;
if isempty(rho)
    rho = 0;
end

lambda =  reshape(mu./repmat(v_av,n_int,n_users),n_users*n_int,2); 
Z1 = mvnrnd([0 0],[1 rho; rho 1],n_int*n_users);
U1 = normcdf(Z1);
X0 = poissinv(U1,lambda);
n_bursts = sum(X0);

switch dst
    case 'pareto'
        k = v_av./(v_av-v_min);
        zr = randn(n_bursts(1),1);
        zs = randn(n_bursts(2),1);
        ur = normcdf(zr);
        us = normcdf(zs);
        
        xr = v_min(1).*(1-ur).^((-1./k(1)));
        xs = v_min(2).*(1-us).^((-1./k(2)));
    otherwise
        display('ERROR: No burst distribution specified!');
end
if ~isempty(v_max)
    xr = min(xr,v_max(1).*ones(numel(xr),1));
    xs = min(xs,v_max(2).*ones(numel(xs),1));
end

% Build sequences
SEQ = zeros(size(X0));
ct_r = X0(:,1) > 0;
CT = cumsum(X0(ct_r,1));
sel = [1,CT(1);CT(1:end-1)+1,CT(2:end)];
for k1 = 1:size(sel,1)
    seq_r0(k1) = sum(xr(sel(k1,1):sel(k1,2)));
end
SEQ(ct_r,1) = seq_r0';

ct_s = X0(:,2) > 0;
CT = cumsum(X0(ct_s,2));
sel = [1,CT(1);CT(1:end-1)+1,CT(2:end)];
for k1 = 1:size(sel,1)
    seq_s0(k1) = sum(xs(sel(k1,1):sel(k1,2)));
end
SEQ(ct_s,2) = seq_s0';

% Received traffic sequence (time x users)
R = reshape(SEQ(:,1),n_int,n_users);
% Sent traffic sequence (time x users)
S = reshape(SEQ(:,2),n_int,n_users);

end

