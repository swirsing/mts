classdef MTS < handle
    % This class implements a traffic model for generating artificial
    % traffic demand in cellular mobile networks based on models derived from network measurement data.
    %   There are two basic models, one for weekdays, and one for weekends.   
    
    properties (Constant) % Constant properties     
        model_name = {'Mobile Traffic Simualtor Version 1.0'};
        model_version = {1.0};   
        basic_int = 3600*24;
        sub_int = 3600;
    end
    
    properties  
        model;                  % Contains model parameters for chosen traffic model (weekend or weekday model)    
        pop_size;               % Population size (number of individual)
        users;                  % List of all users, indicating its user types occuring in model
        types;                  % List of all existing user types occuring in model
        bs_min;                 % Min. burst size [received traffic, sent traffic] (Bytes)
        bs_av;                  % Mean burst size (multiple of v_min) [received traffic, sent traffic] (Bytes)
        bs_max;                 % Max. burst size [received traffic, sent traffic] (Bytes)
        rate_limit;             % NOT YET IMPLEMENTED: Specify rate limit
        queue_max;              % NOT YET IMPLEMENTED: Specify packet queue size (per device)
        daily_vol_correlation;  % Correlation between received and sent traffic (refers to daily volumes)
        time_vector;            % Contains simulated time instants (s) 
        received_traffic;       % RESULT: Contains simulated received traffich in Bytes (rows: time, cols: individuals)
        sent_traffic;           % RESULT: Contains simulated sent traffich in Bytes (rows: time, cols: individuals)
    end
    
    methods 
        function obj = MTS(pop_size,bs_min,bs_av,bs_max,weekday_model)
            % This is the constructor method.             
            try
                obj.pop_size = pop_size;
                obj.bs_min = bs_min;
                obj.bs_max = bs_max;
                obj.bs_av = bs_av;
                switch weekday_model 
                    case 1 % Simulation of weekdays
                        load('current_model_wd.mat');
                        obj.model = mwd;
                        display('INFO: Weekday model loaded.');
                    case 2 % Simulation of weekend days
                        load('current_model_we.mat');
                        obj.model = mwe;
                        display('INFO: Weekend model loaded.')
                    otherwise 
                        display('ERROR: No model loaded!')
                end      
                obj.users = sortrows(discretize(rand(obj.pop_size,1),[cumsum(obj.model.share)-obj.model.share;1])); % Build from model distribution!
                obj.types = unique(obj.users);
                display('INFO: User base created!')
            catch
                display('ERROR: No reference models found/loaded, no scenario created!')
            end 
        end 
        function sim(obj,t_offset,t_increment,t_duration,daily_vol_correlation)
            % Conducts simulation for specified parameters and stores
            % results in RESULTS properties. 
            time_v = ((t_offset + t_increment):t_increment:(t_duration + t_offset))'; 
            m = obj.model;
            if ~isempty(daily_vol_correlation)
                obj.daily_vol_correlation = daily_vol_correlation;
            else
                obj.daily_vol_correlation = 0;
            end
            bs_max = obj.bs_max*t_increment;
            basic_int = obj.basic_int;
            sub_int = obj.sub_int;
            n_sub_int = basic_int/sub_int;

            dt = [t_increment;time_v(2:end)-time_v(1:end-1)];
            t1 = mod(time_v,basic_int);                                      % Calculate seconds WITHIN day / basic interval
            t1(t1==0)= basic_int;
            d =  ceil(time_v./(basic_int));                                  % Calculate no. of DAY / basic interval (in time vector)
            h = mod(ceil(time_v./(sub_int)),n_sub_int);                      % Calculate no. of HOUR / sub interval (in time vector)
            h(h==0) = n_sub_int;
            dh = dt./sub_int;
            T = table(time_v,t1,dt,d,h,dh);
            n_days = max(T.d)-min(T.d)+1;

            % Get user types 
            users = obj.users;
            types = obj.types;
            % Check correlation between received/sent data (only if model has correlation, otherwise use aggregate value)
            try
                corr = m.corr;
            catch
                corr = ones(size(m,1),1).*obj.daily_vol_correlation;
            end
            rt = [];
            st = [];
            for k1 = 1:numel(types)
                m_ref = types(k1);
                n_users = sum(users == m_ref);

                % 1. Generate DAILY vols. 
                [vdr,vds] = dailyVol(corr(m_ref),n_days*n_users,m.v_r_wd_lambda(m_ref),m.v_r_wd_beta(m_ref),m.v_s_wd_lambda(m_ref),m.v_s_wd_beta(m_ref),m.v_dst{m_ref});
                vdr = reshape(vdr,[n_days,n_users]);
                vds = reshape(vds,[n_days,n_users]);

                % 2. Generate average INTERVAL vols.
                act_ind = discretize(T.t1,((0:numel(m.r_mean(m_ref,:)))).*(basic_int./numel(m.r_mean(m_ref,:))),'IncludedEdge','right');
                vir = vdr(T.d,:).*repmat(m.r_mean(m_ref,act_ind)'.*numel(m.r_mean(m_ref,:)).*T.dt./basic_int,1,n_users);
                vis = vds(T.d,:).*repmat(m.s_mean(m_ref,act_ind)'.*numel(m.r_mean(m_ref,:)).*T.dt./basic_int,1,n_users);

                % 3. Generate bursty traffic 
                [R,S] = burstGenerator([vir,vis],[],'pareto',obj.bs_min,obj.bs_max,obj.bs_av); 

                % 4. Save results
                rt = [rt, R];
                st = [st,S];
                display(['INFO: Simulating Traffic Demand. User group: ',num2str(k1),' of ',num2str(numel(types)),'.']);
            end            
            obj.time_vector = time_v;
            obj.received_traffic = rt;
            obj.sent_traffic = st;
        end
        function plot(obj,type,varargin)
            % Provides predefined plot types
            switch type
                case 'aggregate_all'
                    f1 = figure; 
                    inc = obj.time_vector(end) - obj.time_vector(end-1);
                    hold on
                        plot(obj.time_vector,log10(sum(obj.received_traffic')),'Color','b','LineWidth',1.5,'LineStyle','-');
                        plot(obj.time_vector,log10(sum(obj.sent_traffic')),'Color','r','LineWidth',1.5,'LineStyle','-');
                    hold off
                    legend('Received Traffic','Sent Traffic')
                    legend(texlabel('v_{r}(t_n)'),texlabel('v_{s}(t_n)'),'Location','SouthEast')
                    xlim([min(obj.time_vector),max(obj.time_vector)]);
                    xlabel(['Time (',num2str(inc),'s Interval)'])
                    ylabel(texlabel('Log_{10} Bytes per Interval'))
                    set(gca,'box','on');
                otherwise
                    display('ERROR: Plot type not selected.')
            end
        end
    end
    
end


