close all; clear;

% SCENARIO SETUP

% Total duration of simulation (s) 
t_duration = 3600.*24*5;    
% Select weekday [1] or weekend [2] model
weekday_model = 1;
% Time step size (s). Total amount of received sent traffic will be simulated for each interval. 
t_increment = 60*5;                           
% Offset (start time) in (s), starting from monday (weekday traffic) or saturday (weekend traffic) at 00:00.
t_offset = 0;    
% Number of simulated users 
pop_size = 750;   

% TRAFFIC CHARACTERISTICS / BURSTINESS

% Correlation coefficient between upload and download rtaffic volumes
correlation = .75;
% Min. burst size [received traffic, sent traffic] (Bytes)
bs_min = [128,64];                  
% Max. burst size [received traffic, sent traffic] (Bytes)
bs_max = ones(1,2).*1e6;     
 % Mean burst size (multiple of v_min) [received traffic, sent traffic] (Bytes)
bs_av = [8,8].*bs_min;     

% SIMULATION

% Create scenario
mts = MTS(pop_size,bs_min,bs_av,bs_max,weekday_model);
% Simulate traffic
mts.sim(t_offset,t_increment,t_duration,correlation);

% VISUALIZE OUTPUT

mts.plot('aggregate_all')



